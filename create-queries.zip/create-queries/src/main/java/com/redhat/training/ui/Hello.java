package com.redhat.training.ui;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import com.redhat.training.model.Person;
import com.redhat.training.services.PersonService;

@ManagedBean(name = "hello")
public class Hello 
{
	private String name;
	private Long id;
	private List<Person> results;
	private String res;

	@Inject
	private PersonService personService;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

	/*//View all persons in the database table
    public List<Person> getPersons() {
    	return personService.getAllPersons();
    }*/

    /*//view all persons whose name matches the name given in the query
    public void search() {
        results = personService.getPersonsWithName(name);
    }*/

    public List<Person> getResults() {
        return results;
    }

    public void setResults(List<Person> results) {
        this.results = results;
    }
    
    public void save()
    {
    	Person P = new Person();
    	P.setName(name);
    	String response = personService.hello(P);
    	FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(response));
    }

	public String getRes() {
		return res;
	}

	public void setRes(String res) {
		this.res = res;
	}
}
