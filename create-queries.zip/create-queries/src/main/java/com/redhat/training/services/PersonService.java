package com.redhat.training.services;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.redhat.training.model.Person;

@Stateless

public class PersonService {

  @PersistenceContext(unitName="hello")
  private EntityManager entityManager;

  public String hello(Person P) {
		try {
				// let's grab the current date and time on the server
				LocalDateTime today = LocalDateTime.now();

				// format it nicely for on-screen display
				DateTimeFormatter format = DateTimeFormatter.ofPattern("MMM dd yyyy hh:mm:ss a");
				String fdate = today.format(format);
													
				entityManager.persist(P);				
				
				// respond back with Hello and convert the name to UPPERCASE. Also, send the
				// current time on the server.
				return "Hello " + P.getName().toUpperCase() + "!. " + "Time on the server is: " + fdate;
		} catch (Exception e) {
			throw new EJBException(e);
		}
	}
  
  //TODO: Implement a method public List<Person> getAllPersons() and 
  //return Get all Person objects in the Database
  
  
  //TODO: Implement a method public List<Person> getPersonsWithName(String name) and 
  //return Get all Person objects based on name in the Database
  
}
